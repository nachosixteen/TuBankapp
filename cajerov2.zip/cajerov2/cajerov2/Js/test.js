// servicios.js

// Crear una instancia de la clase ServicioCajero
const servicioCajero = new ServicioCajero("Cuenta de Ahorros");

// Definir la función para abonar
function abonar() {
    // Obtener el valor ingresado en el campo de número de cuenta
    const numeroCuenta = document.getElementById("cuenta").value;
    
    // Obtener el valor ingresado en el campo de valor a abonar
    const valorAbonar = parseFloat(document.getElementById("valor").value);
    
    // Realizar el abono llamando al método abonar del objeto servicioCajero
    servicioCajero.abonar(valorAbonar);
}
