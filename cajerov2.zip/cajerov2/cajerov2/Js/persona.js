
export class Persona {
    constructor(id, nombre, apellido, telefono, correo, tipoPersona) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.tipoPersona = tipoPersona;
    }
}
